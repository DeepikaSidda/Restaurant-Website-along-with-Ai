define("@wsb/guac-widget-shared/c/_react_commonjs-external-a1351e34.js", ["exports"], (function(e) {
    "use strict";
    const n = global.React || guac.react;
    e._ = n
})), "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=_react_commonjs-external-a1351e34.js.map