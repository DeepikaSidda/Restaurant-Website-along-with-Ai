define("@wsb/guac-widget-shared/c/interopRequireDefault-c83974f7.js", ["exports", "~/c/_commonjsHelpers"], (function(e, o) {
    "use strict";
    var t = o.c((function(e) {
        e.exports = function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }, e.exports.__esModule = !0, e.exports.default = e.exports
    }));
    e.i = t
})), "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=interopRequireDefault-c83974f7.js.map