export const BACKGROUND = 'background';
export const IMAGE = 'image';
export const CARD_BACKGROUND = 'cardBackground';