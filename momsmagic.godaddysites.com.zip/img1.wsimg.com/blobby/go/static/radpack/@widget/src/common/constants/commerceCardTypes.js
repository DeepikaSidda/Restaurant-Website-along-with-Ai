const cardTypes = {
    MAJOR: 'major',
    MEDIUM: 'medium'
};

export default cardTypes;