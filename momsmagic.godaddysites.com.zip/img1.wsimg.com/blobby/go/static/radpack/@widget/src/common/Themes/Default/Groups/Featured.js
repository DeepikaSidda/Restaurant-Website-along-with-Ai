export function Featured(props) {
    return this.Group(props);
}

export function FeaturedHeading(props) {
    return this.ContentHeading(props);
}

export function FeaturedText(props) {
    return this.ContentText(props);
}