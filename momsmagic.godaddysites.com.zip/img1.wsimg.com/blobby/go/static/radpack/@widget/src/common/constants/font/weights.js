export const LIGHTER = 'lighter';
export const LIGHT = 'light';
export const NORMAL = 'normal';
export const BOLD = 'bold';
export const BOLDER = 'bolder';

export default [LIGHTER, LIGHT, NORMAL, BOLD, BOLDER];