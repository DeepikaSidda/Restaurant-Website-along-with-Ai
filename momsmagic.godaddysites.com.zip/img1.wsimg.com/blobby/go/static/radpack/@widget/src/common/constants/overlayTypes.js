export const CATEGORY = 'category';
export const ACCENT = 'accent';
export const NEUTRAL = 'neutral';
export const PRIMARY = 'primary';
export const NONE = 'none';
export const LIGHT_DARK = 'light_dark'; // light for neutral/light primaries, dark for accent/dark primaries