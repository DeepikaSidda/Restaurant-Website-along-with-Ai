export const EMAIL = 'EMAIL';
export const CONVERSATIONS = 'CONVERSATIONS';
export const REAMAZE = 'REAMAZE';