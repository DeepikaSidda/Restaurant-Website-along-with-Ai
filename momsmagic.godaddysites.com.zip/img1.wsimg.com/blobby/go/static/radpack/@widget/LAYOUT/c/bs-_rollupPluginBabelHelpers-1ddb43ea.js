define("@widget/LAYOUT/c/bs-_rollupPluginBabelHelpers-1ddb43ea.js", ["exports"], (function(e) {
    "use strict";

    function r(e) {
        var r = function(e, r) {
            if ("object" != typeof e || !e) return e;
            var t = e[Symbol.toPrimitive];
            if (void 0 !== t) {
                var n = t.call(e, r || "default");
                if ("object" != typeof n) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }
            return ("string" === r ? String : Number)(e)
        }(e, "string");
        return "symbol" == typeof r ? r : String(r)
    }

    function t() {
        return t = Object.assign ? Object.assign.bind() : function(e) {
            for (var r = 1; r < arguments.length; r++) {
                var t = arguments[r];
                for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            }
            return e
        }, t.apply(this, arguments)
    }
    e._ = function(e, t, n) {
        return (t = r(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }, e.a = t
})), "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-_rollupPluginBabelHelpers-1ddb43ea.js.map