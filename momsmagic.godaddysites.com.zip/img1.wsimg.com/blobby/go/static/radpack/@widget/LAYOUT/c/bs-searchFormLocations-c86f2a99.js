define("@widget/LAYOUT/c/bs-searchFormLocations-c86f2a99.js", ["exports"], (function(o) {
    "use strict";
    o.D = "DESKTOP_NAV_COVER", o.M = "MOBILE_NAV", o.N = "NAV_DRAWER", o.S = "SIDEBAR", o.a = "DESKTOP_NAV"
})), "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-searchFormLocations-c86f2a99.js.map