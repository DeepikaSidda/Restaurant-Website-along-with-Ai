define("@widget/LAYOUT/c/bs-imageToHeaderTreatments-e81a288a.js", ["exports", "~/c/bs-overlayTypes"], (function(e, i) {
    "use strict";
    e.i = function(e) {
        return Object.keys(e).filter((e => e !== i.L))
    }
})), "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-imageToHeaderTreatments-e81a288a.js.map