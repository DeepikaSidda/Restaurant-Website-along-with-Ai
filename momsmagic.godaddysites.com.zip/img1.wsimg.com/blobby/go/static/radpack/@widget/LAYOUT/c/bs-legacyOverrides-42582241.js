define("@widget/LAYOUT/c/bs-legacyOverrides-42582241.js", ["exports"], (function(e) {
    "use strict";
    e.g = function(e, i, n) {
        let o = {};
        return "MENU" === i && "h3" === e && (o = {
            color: "highlight"
        }, "menu3" === n && (o.fontSize = "large")), o
    }
})), "undefined" != typeof window && (window.global = window);
//# sourceMappingURL=bs-legacyOverrides-42582241.js.map