window.cxs && window.cxs.setOptions({
    prefix: "c2-"
});
window.wsb = window.wsb || {};
window.wsb["Theme9"] = window.wsb["Theme9"] || window.radpack("@widget/LAYOUT/bs-layout9-Theme-publish-Theme").then(function(t) {
    return new t.default();
});
window.wsb["FreemiumAd"] = function(e) {
    let {
        adEndpoint: t,
        isPublish: a,
        containerId: o
    } = e;
    const r = 1e4,
        l = /<script[^>]*>([\s\S]*)<\/script>/;
    let n, i, s;

    function c(e) {
        e.preventDefault(), e.stopPropagation();
        const t = new CustomEvent("editor", {
            detail: {
                type: "showModal",
                modal: "plans",
                source: "freemiumAd"
            }
        });
        window.dispatchEvent(t)
    }

    function g(e) {
        if (s = document.getElementById(o), !s) return;
        n = document.createElement("div"), n.style.cssText = "width:100%;", s.prepend(n), i = document.createElement("div"), i.setAttribute("data-freemium-ad", !0), i.style.cssText = `overflow:hidden;width:100%;z-index:${r};position:fixed;left:0;`, i.innerHTML = (e || "").replace(l, ""), s.prepend(i);
        const t = `${i.offsetHeight}px`;
        if (n.style.minHeight = t, window.requestAnimationFrame((() => {
                const e = document.querySelector("[data-stickynav]");
                e && "fixed" === e.style.position && (e.style.top = t)
            })), a) {
            const t = l.exec(e);
            if (t) {
                const e = document.createElement("script");
                e.appendChild(document.createTextNode(t[1])), document.head.appendChild(e)
            }
        } else i.addEventListener("click", c, {
            useCapture: !0
        })
    }
    return function() {
            const e = a && sessionStorage.getItem(t) || "";
            e ? g(e) : window.fetch(t).then((e => e.ok && e.text())).then((e => {
                e && (sessionStorage.setItem(t, e), g(e))
            })).catch((() => {}))
        }(),
        function() {
            !a && i.removeEventListener("click", c, {
                useCapture: !0
            }), s && (s.removeChild(n), s.removeChild(i))
        }
};
window.wsb["FreemiumAd"](JSON.parse("{\"adEndpoint\":\"/markup/ad\",\"isPublish\":true,\"containerId\":\"freemium-ad-144740\"}"));
window.wsb["DynamicFontScaler"] = function(t) {
    let e, {
        containerId: n,
        targetId: o,
        fontSizes: r,
        maxLines: i,
        prioritizeDefault: s
    } = t;
    if ("undefined" == typeof document) return;
    const a = document.getElementById(n),
        c = document.getElementById(o);

    function l(t) {
        return function(t) {
            const e = parseInt(y(t, "padding-left") || 0, 10),
                n = parseInt(y(t, "padding-right") || 0, 10);
            return t.scrollWidth + e + n
        }(t) <= a.clientWidth && function(t) {
            const e = t.offsetHeight,
                n = parseInt(y(t, "line-height"), 10) || 1;
            return Math.floor(e / n)
        }(t) <= i
    }

    function p(t) {
        return parseInt(y(t, "font-size") || 0, 10)
    }

    function d(t) {
        if (1 === t.length) return t[0];
        const e = t.filter(l);
        if (1 === e.length) return e[0];
        if (!e.length) return function(t) {
            return t.sort(((t, e) => p(t) - p(e)))[0]
        }(t);
        return e.sort(((t, e) => p(e) - p(t)))[0]
    }

    function u() {
        if (!a || !c || e === window.innerWidth) return;
        if (c.hasAttribute("data-font-scaled")) return void g();
        e = window.innerWidth;
        const t = Array.prototype.slice.call(a.querySelectorAll(`[data-scaler-id="scaler-${n}"]`)).sort(((t, e) => r.indexOf(t.getAttribute("data-size")) - r.indexOf(e.getAttribute("data-size"))));
        if (a.clientWidth && t.length) {
            const e = a.style.width || "";
            a.style.width = "100%", t.forEach((t => {
                t.style.display = "inline-block", t.style.maxWidth = `${a.clientWidth}px`
            }));
            const n = d(t);
            ! function(t) {
                t.forEach((t => {
                    t.style.display = "none", t.style.maxWidth = ""
                }))
            }(t), a.style.width = e;
            const r = y(n, "font-size"),
                i = c.getAttribute("data-last-size");
            if (r && r !== i) {
                if (s) {
                    const t = y(c, "font-size");
                    if (parseInt(r, 10) >= parseInt(t, 10)) return
                }
                c.setAttribute("data-last-size", r);
                let t = document.querySelector(`#${o}-style`);
                t || (t = document.createElement("style"), t.id = `${o}-style`, document.head.appendChild(t)), t.textContent = `#${c.id} { font-size: ${r} !important; }`
            }
        }
    }

    function g() {
        c && c.removeAttribute("data-last-size");
        const t = document.querySelector(`#${o}-style`);
        t && t.parentNode.removeChild(t)
    }

    function y(t, e) {
        return document.defaultView.getComputedStyle(t).getPropertyValue(e)
    }
    return u(), window.addEventListener("resize", u), () => {
        g(), window.removeEventListener("resize", u)
    }
};
window.wsb["DynamicFontScaler"](JSON.parse("{\"containerId\":\"logo-container-144744\",\"targetId\":\"logo-text-144745\",\"fontSizes\":[\"xxlarge\",\"xlarge\",\"large\"],\"maxLines\":3,\"prioritizeDefault\":true}"));
window.wsb["DynamicFontScaler"](JSON.parse("{\"containerId\":\"logo-container-144753\",\"targetId\":\"logo-text-144754\",\"fontSizes\":[\"xxlarge\",\"xlarge\",\"large\"],\"maxLines\":1,\"prioritizeDefault\":true}"));
window.wsb['context-bs-1'] = JSON.parse("{\"env\":\"production\",\"renderMode\":\"PUBLISH\",\"fonts\":[\"righteous\",\"default\",\"\"],\"colors\":[\"#e5d3bf\"],\"locale\":\"en-IN\",\"language\":\"en\",\"resellerId\":1,\"internalLinks\":{\"9e1ea5ed-aeba-4feb-afd9-1b9d66ba1934\":{\"pageId\":\"fdcfd6c2-cc13-48c3-9ad9-f0a9b10dbd30\",\"routePath\":\"/\"}},\"isHomepage\":true,\"navigationMap\":{\"b4890b78-c81b-469e-9fae-2d491ff37a4c\":{\"isFlyoutMenu\":false,\"active\":false,\"pageId\":\"b4890b78-c81b-469e-9fae-2d491ff37a4c\",\"name\":\"404\",\"href\":\"/404\",\"target\":\"\",\"visible\":false,\"requiresAuth\":false,\"tags\":[\"404\"],\"rel\":\"\",\"type\":\"page\",\"showInFooter\":false},\"fdcfd6c2-cc13-48c3-9ad9-f0a9b10dbd30\":{\"isFlyoutMenu\":false,\"active\":true,\"pageId\":\"fdcfd6c2-cc13-48c3-9ad9-f0a9b10dbd30\",\"name\":\"Home\",\"href\":\"/\",\"target\":\"\",\"visible\":true,\"requiresAuth\":false,\"tags\":[],\"rel\":\"\",\"type\":\"page\",\"showInFooter\":false}},\"dials\":{\"colors\":[{\"id\":\"#e5d3bf\",\"meta\":{\"primary\":\"rgb(229, 211, 191)\",\"accent\":\"rgb(17, 17, 17)\",\"neutral\":\"rgb(255, 255, 255)\"}}],\"fonts\":{\"primary\":{\"id\":\"righteous\",\"description\":\"\",\"tags\":[],\"meta\":{\"order\":33,\"primary\":{\"id\":\"righteous\",\"name\":\"Righteous\",\"url\":\"//fonts.googleapis.com/css?family=Righteous:400&display=swap\",\"family\":\"'Righteous', serif, system-ui\",\"size\":14,\"weight\":400,\"weights\":[400,700],\"styles\":{\"letterSpacing\":\"4px\"}},\"alternate\":{\"id\":\"josefin-sans\",\"name\":\"Josefin Sans\",\"url\":\"//fonts.googleapis.com/css?family=Josefin+Sans:400,600,700&display=swap\",\"family\":\"'Josefin Sans', Arial, sans-serif\",\"size\":16,\"weight\":400,\"weights\":[400,600,700],\"styles\":{\"letterSpacing\":\"normal\",\"textTransform\":\"none\"}}},\"overridesAlternate\":[{\"locales\":[\"vi-VN\"],\"meta\":{\"alternate\":{\"family\":\"Arial, sans-serif\"}}},{\"locales\":[\"ja-JP\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Sans, Meiryo, '\u30E1\u30A4\u30EA\u30AA', sans-serif\"}}},{\"locales\":[\"ko-KR\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Sans, '\uAD74\uB9BC', Gulim, '\uAD74\uB9BC\uCCB4', GulimChe, sans-serif\"}}},{\"locales\":[\"th-TH\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Sans, BrowalliaUPC, Tahoma, sans-serif\"}}},{\"locales\":[\"zh-CN\",\"zh-SG\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Sans, '\u4E2D\u6613\u9ED1\u4F53', SimHei, sans-serif\"}}},{\"locales\":[\"zh-HK\",\"zh-TW\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Slab, '\u5FAE\u8EDF\u6B63\u9ED1\u9AD4', Microsoft JhengHei, sans-serif\"}}}],\"overridesPrimary\":[{\"languages\":[\"en\"],\"meta\":{\"primary\":{\"styles\":{\"textTransform\":\"uppercase\"}}}}]}}},\"theme\":\"Theme9\",\"paintJob\":\"MVP\"}");
Core.utils.deferBootstrap({
    elId: 'bs-1',
    componentName: '@widget/LAYOUT/bs-LinkAwareComponent',
    props: JSON.parse("{\"toggleId\":\"more-144755\",\"label\":\"More\",\"dataAid\":\"NAV_MORE\",\"navBarId\":\"navContainer-144750\",\"widgetId\":\"5e5311e8-1c24-4a66-9f6e-c3f1f0a5b461\",\"section\":\"default\",\"category\":\"neutral\",\"locale\":\"en-IN\",\"env\":\"production\",\"renderMode\":\"PUBLISH\"}"),
    context: JSON.parse("{\"widgetId\":\"5e5311e8-1c24-4a66-9f6e-c3f1f0a5b461\",\"widgetType\":\"HEADER\",\"widgetPreset\":\"header9\",\"group\":\"Nav\",\"groupType\":\"Default\",\"section\":\"default\",\"category\":\"neutral\",\"fontSize\":\"medium\",\"fontFamily\":\"alternate\",\"websiteThemeOverrides\":{\"ButtonPrimary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSpotlight\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSecondary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}}},\"widgetThemeOverrides\":{}}"),
    contextKey: 'context-bs-1',
    radpack: "@widget/LAYOUT/bs-LinkAwareComponent"
}, false);
window.wsb["CalculateSplitNavSpacing"] = function(e) {
    let {
        containerId: a,
        navId: n,
        splitNavId: l,
        logoImageId: i,
        inlineUtilitiesMenu: o,
        forceBreakpoint: r
    } = e;
    let c, s, g, p, d, u, y, m;
    const b = document.getElementById(n),
        v = document.getElementById(l);

    function h() {
        if (s || !b || !T(b)) return;
        p = Array.from(b.children), g = Array.from(b.children), g.forEach(E), o && (d = g.pop(), M(d)), u = g.pop();
        const e = u.querySelector("ul");
        y = e ? Array.from(e.children) : [], b.style.whiteSpace = "normal", m = T(b.parentElement, "floor"), b.style.whiteSpace = "nowrap", window.requestAnimationFrame(f)
    }

    function f() {
        const e = d && d.querySelector("[data-ux='Pipe']");
        e && R(e);
        const t = g,
            a = t.map((e => T(e)));
        const n = d ? T(d) : 0;
        let l = 0,
            i = a.concat(n).findIndex((e => {
                if (l + e > m) return e;
                l += e
            }));
        i < 0 && (i = a.length);
        const o = a.slice(0, i);
        let r, c, s = a.slice(i);
        if (k(s) + n < m) r = !1, c = 0;
        else {
            r = !0, c = T(u);
            let e = 0,
                t = c + n;
            s.some((a => {
                if (t += a, t >= m) return !0;
                e++
            })), s = s.slice(0, e)
        }
        for (; o.length > 1 && B(o, s.concat([c, n]).filter(Boolean));) s.unshift(o.pop());
        const b = Array.from(v.children);
        if (I(b, 0, o.length, M), I(t, 0, o.length, R), I(y, 0, o.length, R), I(b, o.length, o.length + s.length, R), I(t, o.length, o.length + s.length, M), I(y, o.length, o.length + s.length, R), I(b, o.length + s.length, t.length, R), I(t, o.length + s.length, t.length, R), I(y, o.length + s.length, t.length, M), r ? M(u) : R(u), function() {
                const e = p.filter((e => "visible" === e.style.visibility && e.classList.contains("nav-item"))),
                    t = e[e.length - 1];
                t && t.classList.add("last-visible-nav-item")
            }(), e) {
            t.find((e => "visible" === e.style.visibility)) && M(e)
        }
        window.dispatchEvent(new Event("NavItemsResized"))
    }

    function w() {
        window.innerWidth < 1024 && r && r !== t.Q || (window.clearTimeout(c), c = window.setTimeout(h, 50))
    }

    function I(e, t, a, n) {
        e = e.slice(t, a).map(n).concat(e.slice(a))
    }

    function E(e) {
        e.style.visibility = "hidden", e.style.display = "", e.classList.remove("last-visible-nav-item", "visible")
    }

    function R(e) {
        e.style.display = "none", e.classList.remove("visible")
    }

    function M(e) {
        e.style.visibility = "visible", e.style.display = "", e.classList.add("visible")
    }

    function k(e) {
        return e.reduce(((e, t) => e + t), 0)
    }

    function T(e) {
        return "ceil" === (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "ceil") ? Math.ceil(e.getBoundingClientRect().width) : Math.floor(e.getBoundingClientRect().width)
    }

    function B(e, t) {
        if (!t.length && e.length > 1) return !0;
        const a = e[e.length - 1],
            n = k(e),
            l = k(t);
        return Math.abs(n - l) > Math.abs(n - a - (l + a))
    }
    if (w(), window.ResizeObserver) {
        const e = new window.ResizeObserver(w);
        return [document.getElementById(a), document.getElementById(i)].forEach((t => t && e.observe(t))), () => {
            s = !0, e.disconnect()
        }
    }
    return window.addEventListener("resize", w, {
        passive: !0
    }), () => {
        s = !0, window.removeEventListener("resize", w, {
            passive: !0
        })
    }
};
window.wsb["CalculateSplitNavSpacing"](JSON.parse("{\"navId\":\"n-144739144749-navId-2\",\"inlineUtilitiesMenu\":false,\"containerId\":\"navContainer-144750\",\"splitNavId\":\"n-144739144748-navId-1\"}"));
window.wsb["DynamicFontScaler"](JSON.parse("{\"containerId\":\"tagline-container-144759\",\"targetId\":\"dynamic-tagline-144760\",\"fontSizes\":[\"xxlarge\",\"xlarge\",\"large\"],\"maxLines\":4}"));
window.wsb['context-bs-2'] = JSON.parse("{\"env\":\"production\",\"renderMode\":\"PUBLISH\",\"fonts\":[\"righteous\",\"default\",\"\"],\"colors\":[\"#e5d3bf\"],\"fontScale\":\"medium\",\"locale\":\"en-IN\",\"language\":\"en\",\"resellerId\":1,\"internalLinks\":{\"9e1ea5ed-aeba-4feb-afd9-1b9d66ba1934\":{\"pageId\":\"fdcfd6c2-cc13-48c3-9ad9-f0a9b10dbd30\",\"routePath\":\"/\"}},\"isHomepage\":true,\"navigationMap\":{\"b4890b78-c81b-469e-9fae-2d491ff37a4c\":{\"isFlyoutMenu\":false,\"active\":false,\"pageId\":\"b4890b78-c81b-469e-9fae-2d491ff37a4c\",\"name\":\"404\",\"href\":\"/404\",\"target\":\"\",\"visible\":false,\"requiresAuth\":false,\"tags\":[\"404\"],\"rel\":\"\",\"type\":\"page\",\"showInFooter\":false},\"fdcfd6c2-cc13-48c3-9ad9-f0a9b10dbd30\":{\"isFlyoutMenu\":false,\"active\":true,\"pageId\":\"fdcfd6c2-cc13-48c3-9ad9-f0a9b10dbd30\",\"name\":\"Home\",\"href\":\"/\",\"target\":\"\",\"visible\":true,\"requiresAuth\":false,\"tags\":[],\"rel\":\"\",\"type\":\"page\",\"showInFooter\":false}},\"dials\":{\"colors\":[{\"id\":\"#e5d3bf\",\"meta\":{\"primary\":\"rgb(229, 211, 191)\",\"accent\":\"rgb(17, 17, 17)\",\"neutral\":\"rgb(255, 255, 255)\"}}],\"fonts\":{\"primary\":{\"id\":\"righteous\",\"description\":\"\",\"tags\":[],\"meta\":{\"order\":33,\"primary\":{\"id\":\"righteous\",\"name\":\"Righteous\",\"url\":\"//fonts.googleapis.com/css?family=Righteous:400&display=swap\",\"family\":\"'Righteous', serif, system-ui\",\"size\":14,\"weight\":400,\"weights\":[400,700],\"styles\":{\"letterSpacing\":\"4px\"}},\"alternate\":{\"id\":\"josefin-sans\",\"name\":\"Josefin Sans\",\"url\":\"//fonts.googleapis.com/css?family=Josefin+Sans:400,600,700&display=swap\",\"family\":\"'Josefin Sans', Arial, sans-serif\",\"size\":16,\"weight\":400,\"weights\":[400,600,700],\"styles\":{\"letterSpacing\":\"normal\",\"textTransform\":\"none\"}}},\"overridesAlternate\":[{\"locales\":[\"vi-VN\"],\"meta\":{\"alternate\":{\"family\":\"Arial, sans-serif\"}}},{\"locales\":[\"ja-JP\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Sans, Meiryo, '\u30E1\u30A4\u30EA\u30AA', sans-serif\"}}},{\"locales\":[\"ko-KR\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Sans, '\uAD74\uB9BC', Gulim, '\uAD74\uB9BC\uCCB4', GulimChe, sans-serif\"}}},{\"locales\":[\"th-TH\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Sans, BrowalliaUPC, Tahoma, sans-serif\"}}},{\"locales\":[\"zh-CN\",\"zh-SG\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Sans, '\u4E2D\u6613\u9ED1\u4F53', SimHei, sans-serif\"}}},{\"locales\":[\"zh-HK\",\"zh-TW\"],\"meta\":{\"alternate\":{\"family\":\"Josefin Slab, '\u5FAE\u8EDF\u6B63\u9ED1\u9AD4', Microsoft JhengHei, sans-serif\"}}}],\"overridesPrimary\":[{\"languages\":[\"en\"],\"meta\":{\"primary\":{\"styles\":{\"textTransform\":\"uppercase\"}}}}]}}},\"theme\":\"Theme9\"}");
Core.utils.deferBootstrap({
    elId: 'bs-2',
    componentName: '@widget/GALLERY/bs-gallery3-Gallery',
    props: JSON.parse("{\"upgradeable\":false,\"preset\":\"gallery3\",\"id\":\"873bd296-9d43-4490-9a30-adc21ed9a22d\",\"galleryImages\":[{\"image\":{\"image\":\"//img1.wsimg.com/isteam/stock/18544\"}},{\"image\":{\"image\":\"//img1.wsimg.com/isteam/stock/18546\"}},{\"image\":{\"image\":\"//img1.wsimg.com/isteam/stock/99133\"}},{\"image\":{\"image\":\"//img1.wsimg.com/isteam/stock/874\"}},{\"image\":{\"image\":\"//img1.wsimg.com/isteam/stock/85283\"}},{\"image\":{\"image\":\"//img1.wsimg.com/isteam/stock/18549\"}}],\"viewDevice\":null,\"staticContent\":{\"showMore\":\"Show More\",\"demoCaption1\":\"Use captions to provide more information about your photos\",\"demoCaption2\":\"Captions can prompt viewers to act. You can even insert a link\",\"demoCaption3\":\"Use the caption to call out things the viewer may not notice\",\"showLess\":\"Show Less\"},\"title\":\"A Visual Feast: Discover the Vibrant World of Mom's magic  Through Our Photo Collection\",\"autoplay\":false,\"autoplayDelay\":\"3.5\",\"transitionType\":\"slide\",\"showSlideNum\":true,\"showArrows\":true,\"fullBleed\":false,\"showthumbnailsThirdLayout\":true,\"images\":[{\"lightboxUrl\":\"//img1.wsimg.com/isteam/stock/18544/:/\",\"index\":0,\"position\":\"center\",\"imageData\":{\"image\":\"//img1.wsimg.com/isteam/stock/18544\",\"src\":\"//img1.wsimg.com/isteam/stock/18544\"}},{\"lightboxUrl\":\"//img1.wsimg.com/isteam/stock/18546/:/\",\"index\":1,\"position\":\"center\",\"imageData\":{\"image\":\"//img1.wsimg.com/isteam/stock/18546\",\"src\":\"//img1.wsimg.com/isteam/stock/18546\"}},{\"lightboxUrl\":\"//img1.wsimg.com/isteam/stock/99133/:/\",\"index\":2,\"position\":\"center\",\"imageData\":{\"image\":\"//img1.wsimg.com/isteam/stock/99133\",\"src\":\"//img1.wsimg.com/isteam/stock/99133\"}},{\"lightboxUrl\":\"//img1.wsimg.com/isteam/stock/874/:/\",\"index\":3,\"position\":\"center\",\"imageData\":{\"image\":\"//img1.wsimg.com/isteam/stock/874\",\"src\":\"//img1.wsimg.com/isteam/stock/874\"}},{\"lightboxUrl\":\"//img1.wsimg.com/isteam/stock/85283/:/\",\"index\":4,\"position\":\"center\",\"imageData\":{\"image\":\"//img1.wsimg.com/isteam/stock/85283\",\"src\":\"//img1.wsimg.com/isteam/stock/85283\"}},{\"lightboxUrl\":\"//img1.wsimg.com/isteam/stock/18549/:/\",\"index\":5,\"position\":\"center\",\"imageData\":{\"image\":\"//img1.wsimg.com/isteam/stock/18549\",\"src\":\"//img1.wsimg.com/isteam/stock/18549\"}}],\"renderAsThumbnail\":false,\"widgetId\":\"873bd296-9d43-4490-9a30-adc21ed9a22d\",\"section\":\"alt\",\"category\":\"neutral\",\"locale\":\"en-IN\",\"env\":\"production\",\"renderMode\":\"PUBLISH\"}"),
    context: JSON.parse("{\"order\":1,\"widgetId\":\"873bd296-9d43-4490-9a30-adc21ed9a22d\",\"widgetType\":\"GALLERY\",\"widgetPreset\":\"gallery3\",\"group\":\"Section\",\"groupType\":\"Default\",\"section\":\"alt\",\"category\":\"neutral\",\"fontSize\":\"medium\",\"fontFamily\":\"alternate\",\"websiteThemeOverrides\":{\"ButtonPrimary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSpotlight\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSecondary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}}},\"widgetThemeOverrides\":{}}"),
    contextKey: 'context-bs-2',
    radpack: "@widget/GALLERY/bs-gallery3-Gallery"
}, false);
Core.utils.deferBootstrap({
    elId: 'bs-3',
    componentName: '@widget/CONTACT/bs-Component',
    props: JSON.parse("{\"structuredHours\":[{\"hour\":{\"day\":\"Monday\",\"dayOfWeek\":1,\"openTime\":\"09:00\",\"closeTime\":\"17:00\",\"byAppointmentOnly\":false,\"closed\":false}},{\"hour\":{\"day\":\"Tuesday\",\"dayOfWeek\":2,\"openTime\":\"09:00\",\"closeTime\":\"17:00\",\"byAppointmentOnly\":false,\"closed\":false}},{\"hour\":{\"day\":\"Wednesday\",\"dayOfWeek\":3,\"openTime\":\"09:00\",\"closeTime\":\"17:00\",\"byAppointmentOnly\":false,\"closed\":false}},{\"hour\":{\"day\":\"Thursday\",\"dayOfWeek\":4,\"openTime\":\"09:00\",\"closeTime\":\"17:00\",\"byAppointmentOnly\":false,\"closed\":false}},{\"hour\":{\"day\":\"Friday\",\"dayOfWeek\":5,\"openTime\":\"09:00\",\"closeTime\":\"17:00\",\"byAppointmentOnly\":false,\"closed\":false}},{\"hour\":{\"day\":\"Saturday\",\"dayOfWeek\":6,\"openTime\":\"09:00\",\"closeTime\":\"17:00\",\"byAppointmentOnly\":false,\"closed\":false}},{\"hour\":{\"day\":\"Sunday\",\"dayOfWeek\":0,\"openTime\":\"09:00\",\"closeTime\":\"17:00\",\"byAppointmentOnly\":true,\"closed\":false}}],\"staticContent\":{\"today\":\"Today\",\"submitButtonLoadingLabel\":\"Sending\",\"contactFormResponseErrorMessage\":\"Something went wrong while sending your message, please try again later\",\"phoneValidationErrorMessage\":\"Please enter a valid phone number.\",\"defaultCancelButtonLabel\":\"Cancel\",\"byAppointment\":\"By Appointment\",\"defaultSubmitButtonLabel\":\"Send\",\"unsupportedFileType\":\"Unsupported file type\",\"maxFileCountLimit\":\"Only {0} files are allowed\",\"closed\":\"Closed\",\"attachments\":\"Attachments\",\"termsOfSerivce\":\"Terms of Service\",\"attachFiles\":\"Attach Files\",\"recaptchaDisclosure\":\"This site is protected by reCAPTCHA and the Google {privacyPolicy} and {termsOfSerivce} apply.\",\"emailValidationErrorMessage\":\"Please enter a valid email address.\",\"mapCTA\":\"Get directions\",\"privacyPolicyURL\":\"https://policies.google.com/privacy\",\"requiredValidationErrorMessage\":\"Please fill in this required field\",\"openToday\":\"Open today\",\"couldNotAttach\":\"Could not attach the following file(s)\",\"totalFileSizeLimit\":\"Total files would exceed {0} limit\",\"privacyPolicy\":\"Privacy Policy\",\"termsOfSerivceURL\":\"https://policies.google.com/terms\",\"fileSizeLimit\":\"File exceeds {0} limit\",\"emailMaxCountValidationErrorMessage\":\"Your email address is too long\"},\"collapsible\":true,\"widgetId\":\"323e8438-40fd-4a45-a322-a7bad8c0d731\",\"section\":\"alt\",\"category\":\"neutral\",\"locale\":\"en-IN\",\"env\":\"production\",\"renderMode\":\"PUBLISH\"}"),
    context: JSON.parse("{\"order\":3,\"widgetId\":\"323e8438-40fd-4a45-a322-a7bad8c0d731\",\"widgetType\":\"CONTACT\",\"widgetPreset\":\"contact5\",\"group\":\"Content\",\"groupType\":\"Default\",\"section\":\"alt\",\"category\":\"neutral\",\"fontSize\":\"medium\",\"fontFamily\":\"alternate\",\"websiteThemeOverrides\":{\"ButtonPrimary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSpotlight\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSecondary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}}},\"widgetThemeOverrides\":{}}"),
    contextKey: 'context-bs-2',
    radpack: "@widget/CONTACT/bs-Component"
}, false);
Core.utils.deferBootstrap({
    elId: 'bs-4',
    componentName: '@widget/CONTACT/bs-genericMap',
    props: JSON.parse("{\"lat\":\"15.5088876\",\"lon\":\"73.7694377\",\"address\":\"Acron Seaway Resort,183,Fort Aguda Rd,Candolim,Goa 456736\",\"type\":\"google\",\"isEditMode\":false,\"zoom\":14,\"mapboxAccessToken\":\"pk.eyJ1IjoiZ29kYWRkeSIsImEiOiJjaWc5b20wcjcwczAydGFsdGxvamdvYnV0In0.JK9HuO6nAzc8BnMv6W7NBQ\",\"mapboxStyleUrl\":\"mapbox://styles/godaddy/ciovyeygh0029atm6zbntgxk2\",\"staticContent\":{\"today\":\"Today\",\"submitButtonLoadingLabel\":\"Sending\",\"contactFormResponseErrorMessage\":\"Something went wrong while sending your message, please try again later\",\"phoneValidationErrorMessage\":\"Please enter a valid phone number.\",\"defaultCancelButtonLabel\":\"Cancel\",\"byAppointment\":\"By Appointment\",\"defaultSubmitButtonLabel\":\"Send\",\"unsupportedFileType\":\"Unsupported file type\",\"maxFileCountLimit\":\"Only {0} files are allowed\",\"closed\":\"Closed\",\"attachments\":\"Attachments\",\"termsOfSerivce\":\"Terms of Service\",\"attachFiles\":\"Attach Files\",\"recaptchaDisclosure\":\"This site is protected by reCAPTCHA and the Google {privacyPolicy} and {termsOfSerivce} apply.\",\"emailValidationErrorMessage\":\"Please enter a valid email address.\",\"mapCTA\":\"Get directions\",\"privacyPolicyURL\":\"https://policies.google.com/privacy\",\"requiredValidationErrorMessage\":\"Please fill in this required field\",\"openToday\":\"Open today\",\"couldNotAttach\":\"Could not attach the following file(s)\",\"totalFileSizeLimit\":\"Total files would exceed {0} limit\",\"privacyPolicy\":\"Privacy Policy\",\"termsOfSerivceURL\":\"https://policies.google.com/terms\",\"fileSizeLimit\":\"File exceeds {0} limit\",\"emailMaxCountValidationErrorMessage\":\"Your email address is too long\"},\"viewDevice\":null,\"widgetId\":\"323e8438-40fd-4a45-a322-a7bad8c0d731\",\"section\":\"alt\",\"category\":\"neutral\",\"locale\":\"en-IN\",\"env\":\"production\",\"renderMode\":\"PUBLISH\"}"),
    context: JSON.parse("{\"order\":3,\"widgetId\":\"323e8438-40fd-4a45-a322-a7bad8c0d731\",\"widgetType\":\"CONTACT\",\"widgetPreset\":\"contact5\",\"group\":\"Map\",\"groupType\":\"Banner\",\"section\":\"alt\",\"category\":\"neutral\",\"fontSize\":\"medium\",\"fontFamily\":\"alternate\",\"websiteThemeOverrides\":{\"ButtonPrimary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSpotlight\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSecondary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}}},\"widgetThemeOverrides\":{}}"),
    contextKey: 'context-bs-2',
    radpack: "@widget/CONTACT/bs-genericMap"
}, false);
Core.utils.deferBootstrap({
    elId: 'bs-5',
    componentName: '@widget/REVIEWS/bs-Component',
    props: JSON.parse("{\"hasBgImage\":true,\"upgradeable\":false,\"preset\":\"reviews1\",\"id\":\"e8767534-0bac-4276-82ae-4a7ed82e2ea5\",\"planType\":\"businessPlus\",\"market\":\"en-IN\",\"publishDate\":\"2024-03-05T16:41:18.551Z\",\"fbPageId\":null,\"gmbShowPendingMessage\":false,\"publishAfterLastUpgrade\":false,\"providerType\":\"facebook\",\"isInternalPage\":false,\"isReseller\":false,\"accountId\":\"6e732a8b-db00-11ee-833e-3417ebe72595\",\"viewDevice\":null,\"sectionTitle\":\"Word of Mouth: What our customers are saying\",\"background\":{\"image\":\"//img1.wsimg.com/isteam/stock/99133\"},\"staticContent\":{\"txtPendingValidation\":\"Pending Validation\",\"reviewTitle\":\"Title\",\"add\":\"Add\",\"doesNotRecommend\":\"Doesn't recommend\",\"noWrittenReviews\":\"This customer did not write a review.\",\"connectionSuccess\":\"Successfully Connected!\",\"cantConnect\":\"Why can't I connect yet?\",\"reviewDate\":\"Review Date\",\"productReview\":\"{totalReviews} Product Review\",\"viewAllProductReviews\":\"View All {totalReviews} Product Reviews\",\"upgradeMessage\":\"Your site needs to have an online store to use {provider} reviews\",\"productReviews\":\"{totalReviews} Product Reviews\",\"goToProduct\":\"Go to {productName}\",\"anonymous\":\"Anonymous\",\"gmb3Days\":\"It may take up to 3 days to validate your business. Until then, reviews will not appear on your site.\",\"noReviewsYet\":\"There are no reviews yet.\",\"reviewerName\":\"Reviewer Name\",\"basedOn\":\"Based on the opinion of {reviewCount} people\",\"photo\":\"Photo\",\"gmbAwaitingData\":\"We are waiting for data. Please check back later\",\"reviewLink\":\"Review Link\",\"basedOnOne\":\"Based on the opinion of 1 person\",\"gmbUnderReview\":\"Google is reviewing your business info. We'll let you know when your listing is live.\",\"gmbPublishMessage\":\"Your website needs to be published before connecting to Google My Business.\",\"sourceMsgStatic\":\"Add reviews manually\",\"manualReviews\":\"Reviews\",\"ratingNone\":\"None\",\"reviewRating\":\"Rating\",\"percentRecommend\":\"{percent} recommend\",\"connectMsg\":\"To show reviews on your site, connect your account to {provider}\",\"twentyFourHourLag\":\"Data may take up to 24 hours to display.\",\"recommends\":\"Recommends\",\"reviewFirst\":\"Be the first to leave a review\",\"review\":\"{totalReviews} Review\",\"publishMessage\":\"Your website needs to be published before connecting to {provider}\",\"sourceMsgDynamic\":\"Connect to external source\",\"reviewBody\":\"Review\",\"upgradeNow\":\"Add Store Now\",\"viewMore\":\"View More\",\"reviews\":\"{totalReviews} Reviews\",\"cantConnectMsg\":\"Your website needs to be published before connecting to {provider}\",\"comingSoon\":\"Reviews coming soon!\",\"readFullReview\":\"Read full review\",\"labelForDeleteManualReview\":\"Delete Review\",\"gmbNoReviews\":\"You are successfully connected but there are no reviews yet.\",\"connectBtnText\":\"Connect to {provider}\",\"viewAllReviews\":\"View All {totalReviews} Reviews\"},\"websiteId\":\"55a62a9b-1392-4d0c-93c5-bbb5d1ee8a28\",\"sourceType\":\"dynamic\",\"manualReviews\":[{\"photo\":{},\"title\":\"Title 1\",\"body\":\"Review 1\",\"rating\":\"0\",\"name\":\"Anonymous\",\"date\":\"5/3/2024\"},{\"photo\":{},\"title\":\"Title 2\",\"body\":\"Review 2\",\"rating\":\"0\",\"name\":\"Anonymous\",\"date\":\"5/3/2024\"},{\"photo\":{},\"title\":\"Title 3\",\"body\":\"Review 3\",\"rating\":\"0\",\"name\":\"Anonymous\",\"date\":\"5/3/2024\"}],\"widgetId\":\"e8767534-0bac-4276-82ae-4a7ed82e2ea5\",\"section\":\"default\",\"category\":\"neutral\",\"locale\":\"en-IN\",\"env\":\"production\",\"renderMode\":\"PUBLISH\"}"),
    context: JSON.parse("{\"order\":4,\"widgetId\":\"e8767534-0bac-4276-82ae-4a7ed82e2ea5\",\"widgetType\":\"REVIEWS\",\"widgetPreset\":\"reviews1\",\"group\":\"Section\",\"groupType\":\"Banner\",\"section\":\"default\",\"category\":\"neutral\",\"fontSize\":\"medium\",\"fontFamily\":\"alternate\",\"websiteThemeOverrides\":{\"ButtonPrimary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSpotlight\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSecondary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}}},\"widgetThemeOverrides\":{}}"),
    contextKey: 'context-bs-2',
    radpack: "@widget/REVIEWS/bs-Component"
}, false);
window.wsb["CookieBannerScript"] = function(e) {
    let {
        id: t,
        acceptCookie: o,
        dismissCookie: a
    } = e;
    const n = 864e5;
    let i, l, r;

    function s(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 60;
        const o = new Date;
        o.setTime(o.getTime() + n * t);
        const a = `expires=${o.toUTCString()}`;
        document.cookie = `${e}=true;${a};path=/`
    }

    function c(e) {
        return document.cookie.includes(e)
    }

    function p() {
        l && l.removeEventListener("click", g), r && r.removeEventListener("click", d), i.style.display = "none"
    }

    function g(e) {
        e.preventDefault(), u(), s(a), s(o), p()
    }

    function d(e) {
        var t;
        e.preventDefault(), s(a), c(o) && (t = o, document.cookie = `${t}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`), p()
    }

    function u() {
        window._allowCT = !0, window._allowCTListener && window._allowCTListener.forEach((e => e()))
    }
    c(o) ? u() : c(a) || setTimeout((() => {
        i = document.getElementById(`${t}-banner`), l = document.getElementById(`${t}-accept`), r = document.getElementById(`${t}-decline`), l && l.addEventListener("click", g), r && r.addEventListener("click", d), i.style.transform = "translateY(-500px)"
    }), 200)
};
window.wsb["CookieBannerScript"](JSON.parse("{\"id\":\"939da086-a13a-43c0-9a46-68a538633241\",\"dismissCookie\":\"cookie_warning_dismissed\",\"acceptCookie\":\"cookie_terms_accepted\"}"));
Core.utils.renderBootstrap({
    elId: 'bs-6',
    componentName: '@widget/MESSAGING/bs-Component',
    props: JSON.parse("{\"config\":{\"formSubmitEndpoint\":\"/messaging\",\"assetsHost\":\"https://img1.wsimg.com\",\"assetsBasePath\":\"/isteam\",\"contactsHost\":\"https://contacts.godaddy.com\",\"conversationsWebHost\":\"https://conversations.godaddy.com\",\"formSubmitHost\":\"https://contact.apps-api.instantpage.secureserver.net\",\"generateUrlHost\":\"https://url-generator.apps.secureserver.net\",\"vNextApiHost\":\"https://websites.api.godaddy.com\",\"reamazeApiHost\":\"https://{{websiteId}}reamaze.godaddy.com\",\"reamazeJsSource\":\"https://cdn.reamaze.com/assets/reamaze-loader.js\",\"reamazeCookieJsSource\":\"https://cdn.reamaze.com/assets/reamaze-godaddy-loader.js\"},\"businessName\":\"Mom's magic \",\"reamazeBrandId\":\"55a62a9b-1392-4d0c-93c5-bbb5d1ee8a28\",\"welcomeMessage\":\"Hi! Let us know how we can help and we\u2019ll respond shortly.\",\"formSuccessMessage\":\"Thanks for the message. We'll get back to you as soon as we can.\",\"emailOptInMessage\":\"Sign up to receive email updates, announcements, and more.\",\"emailOptInEnabled\":false,\"domainName\":\"momsmagic.godaddysites.com\",\"cookieBannerEnabled\":true,\"formFields\":[{\"keyName\":\"name\",\"type\":\"SINGLE_LINE\",\"label\":\"Name\",\"validation\":\"required\",\"required\":true},{\"keyName\":\"phone\",\"type\":\"PHONE\",\"label\":\"Mobile\",\"validation\":\"phone\",\"required\":true},{\"keyName\":\"email\",\"type\":\"EMAIL\",\"label\":\"Email\",\"validation\":\"email\",\"required\":true,\"replyTo\":true},{\"keyName\":\"message\",\"type\":\"MULTI_LINE\",\"label\":\"How can we help?\",\"validation\":\"required\",\"required\":true},{\"type\":\"SUBMIT\",\"label\":\"Send\"}],\"accountId\":\"6e732a8b-db00-11ee-833e-3417ebe72595\",\"websiteId\":\"55a62a9b-1392-4d0c-93c5-bbb5d1ee8a28\",\"id\":\"bd1b1e57-af69-45ae-aee0-da53ec4543e0\",\"staticContent\":{\"submitButtonLoadingLabel\":\"Sending\",\"infoStartTitle\":\"Conversations\",\"contactFormResponseErrorMessage\":\"Something went wrong while sending your message, please try again later\",\"infoStartDesc\":\"Respond smarter and faster to website messages, text messages and Facebook Messenger. Receive instant notifications, reply from anywhere, all from your phone.\",\"infoStartTag\":\"New\",\"phoneValidationErrorMessage\":\"Please enter a valid phone number.\",\"defaultCancelButtonLabel\":\"Cancel\",\"contactsLinkInfoMessaging\":\"Contacts from your website messaging form are captured in Connections.\",\"defaultSubmitButtonLabel\":\"Send\",\"endOfChat\":\"end of chat\",\"infoConnectedDesc\":\"You are connected to the Conversations mobile app and are currently receiving all website messages there.\",\"infoRecommendedTag\":\"Recommended\",\"infoStartLink\":\"Get Started\",\"phoneUsOnlyValidationErrorMessage\":\"Please enter a valid U.S. mobile phone number.\",\"infoIncludedTag\":\"Included\",\"infoPublishRequiredDesc\":\"A publish is needed in order to complete this first step of enabling this feature.\",\"infoPendingLoginDesc\":\"A text message has been sent to you to download the Conversations app. Please download and install to complete set up.\",\"termsOfSerivce\":\"Terms of Service\",\"infoUnavailableDesc\":\"We currently only allow this to work with one website. To use this feature on this website, please disconnect from the active one.\",\"recaptchaDisclosure\":\"This site is protected by reCAPTCHA and the Google {privacyPolicy} and {termsOfSerivce} apply.\",\"emailValidationErrorMessage\":\"Please enter a valid email address.\",\"privacyPolicyURL\":\"https://policies.google.com/privacy\",\"infoUnavailableTitle\":\"Conversations\",\"requiredValidationErrorMessage\":\"Please fill in this required field\",\"infoUnavailableTag\":\"Unavailable\",\"contactsLinkText\":\"Manage my contacts\",\"privacyPolicy\":\"Privacy Policy\",\"infoPublishRequiredLink\":\"Publish Now\",\"infoPendingLoginLink\":\"Resend Link\",\"infoConnectedTitle\":\"Conversations Mobile App\",\"termsOfSerivceURL\":\"https://policies.google.com/terms\",\"messagesRatesLegalDisclosure\":\"By submitting your phone number, you agree to receive text messages from us. Message/ data rates may apply.\",\"emailMaxCountValidationErrorMessage\":\"Your email address is too long\",\"infoConnectedTag\":\"Connected\"},\"emailConfirmationMessage\":\"We've sent you a confirmation email, please click the link to verify your address.\",\"recaptchaType\":\"V3\",\"isMobile\":null,\"notificationPreference\":\"EMAIL\",\"isReseller\":false,\"reamazePrompt\":\"Let me know if you have any questions!\",\"reamazePromptEnabled\":true,\"reamazeThemeColor\":\"#e5d3bf\",\"reamazePosition\":\"bottom-right\",\"reamazeConfirmationMessage\":\"Thanks! Your message has been submitted. We'll get back to you here or via email.\",\"reamazeAvatarImage\":\"\",\"widgetId\":\"bd1b1e57-af69-45ae-aee0-da53ec4543e0\",\"section\":\"default\",\"category\":\"neutral\",\"locale\":\"en-IN\",\"env\":\"production\",\"renderMode\":\"PUBLISH\"}"),
    context: JSON.parse("{\"widgetId\":\"bd1b1e57-af69-45ae-aee0-da53ec4543e0\",\"widgetType\":\"MESSAGING\",\"widgetPreset\":\"messaging1\",\"section\":\"default\",\"category\":\"neutral\",\"fontSize\":\"medium\",\"fontFamily\":\"alternate\",\"websiteThemeOverrides\":{\"ButtonPrimary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSpotlight\":{\"value\":{\"color\":\"HIGHCONTRAST\"}},\"ButtonSecondary\":{\"value\":{\"color\":\"HIGHCONTRAST\"}}},\"widgetThemeOverrides\":{}}"),
    contextKey: 'context-bs-2',
    radpack: "@widget/MESSAGING/bs-Component"
});
document.getElementById('page-144738').addEventListener('click', function() {}, false);
var t = document.createElement("script");
t.type = "text/javascript", t.addEventListener("load", () => {
    window.tti.calculateTTI(({
        name: t,
        value: e
    } = {}) => {
        let i = {
            "wam_site_hasPopupWidget": false,
            "wam_site_hasMessagingWidget": true,
            "wam_site_headerTreatment": "Fill",
            "wam_site_hasSlideshow": false,
            "wam_site_hasFreemiumBanner": false,
            "wam_site_homepageFirstWidgetType": "ABOUT",
            "wam_site_homepageFirstWidgetPreset": "about7",
            "wam_site_businessCategory": "indpak",
            "wam_site_theme": "layout9",
            "wam_site_locale": "en-IN",
            "wam_site_fontPack": "righteous",
            "wam_site_cookieBannerEnabled": true,
            "wam_site_membershipEnabled": true,
            "wam_site_hasHomepageHTML": false,
            "wam_site_hasHomepageShop": false,
            "wam_site_hasHomepageOla": false,
            "wam_site_hasHomepageBlog": false,
            "wam_site_hasShop": false,
            "wam_site_hasOla": false,
            "wam_site_planType": "businessPlus",
            "wam_site_isHomepage": true,
            "wam_site_htmlWidget": false
        };
        window.networkInfo && window.networkInfo.downlink && (i = Object.assign({}, i, {
            ["wam_site_networkSpeed"]: window.networkInfo.downlink.toFixed(2)
        })), window.tti.setCustomProperties(i), window.tti._collectVitals({
            name: t,
            value: e
        })
    })
}), t.setAttribute("src", "//img1.wsimg.com/traffic-assets/js/tccl-tti.min.js"), document.body.appendChild(t);